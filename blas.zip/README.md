# WhatsApp Blaster Bot Telegram

Bot Telegram profesional untuk blast pesan WhatsApp menggunakan Node.js, Baileys, dan JSON Database.

## Fitur

- **WhatsApp Multi Device** (Pairing Code & QR Code)
- **Auto Reconnect & Session Restore**
- **Upload Kontak** (TXT, CSV, XLS, XLSX, PDF, ZIP, VCF)
- **Template Pesan** (HTML, Emoji, Media)
- **Blast Real-time** dengan Progress Bar
- **Pause, Resume, Stop** Blast
- **Anti Kirim Ulang** (Riwayat per User)
- **Sistem Saldo** & Withdraw (Approve/Reject Owner)
- **Panel Admin Lengkap**
- **Auto Backup JSON**
- **HTML Parse Mode** dengan desain modern

## Instalasi

### VPS / Railway / Termux (Normal)

```bash
cd bot
npm install
cp .env.example .env
# Edit .env isi BOT_TOKEN dan OWNER_ID
npm start
```

### Pterodactyl Panel (Khusus - EALLOWGIT Fix)

Pterodactyl sering memblokir `git+https` dependency (libsignal-node). Gunakan cara ini:

**Cara 1: Setup Script (Rekomendasi)**
```bash
# 1. Upload semua file ke Pterodactyl
# 2. Jalankan setup:
node setup-pterodactyl.js

# 3. Setelah setup berhasil, install dependency:
npm install --legacy-peer-deps

# 4. Jalankan bot:
npm start
```

**Cara 2: Startup Command Pterodactyl**
```bash
node setup-pterodactyl.js && npm install --legacy-peer-deps && npm start
```

**Cara 3: Upload node_modules (Fallback 100% Work)**
Jika Cara 1 & 2 gagal:
```bash
# Di PC/laptop Anda:
cd bot
npm install
zip -r node_modules.zip node_modules/

# Upload node_modules.zip ke Pterodactyl
# Extract di Pterodactyl
# Jalankan: npm start
```

## Konfigurasi .env

```env
BOT_TOKEN=your_telegram_bot_token
OWNER_ID=123456789,987654321
DEFAULT_PRICE=500
MIN_WITHDRAW=50000
DEFAULT_DELAY=5
PORT=3000
TZ=Asia/Jakarta
AUTO_BACKUP_INTERVAL=24
```

## Struktur Folder

```
bot/
├── index.js
├── package.json
├── .env.example
├── .npmrc              # Config npm untuk Pterodactyl
├── setup-pterodactyl.js # Script setup khusus Pterodactyl
├── database/           # JSON Files
├── handler/            # WhatsApp, Blast, Upload, Admin
├── command/            # Telegram Commands
├── utils/              # Database, Helper, Logger
├── session/            # Baileys Auth Sessions
├── uploads/            # File Uploads
├── temp/               # Temp Files
└── logs/               # Application Logs
```

## Command Telegram

| Command | Keterangan |
|---------|-----------|
| `/start` | Dashboard utama |

## Panel Admin (Owner Only)

- Tambah/Kurangi Saldo
- Edit Harga Blast
- Edit Min Withdraw
- Edit Delay Default
- Broadcast ke Semua User
- Lihat Semua User
- Reset Riwayat Blast
- Backup & Restore JSON
- Logout Semua Session
- Approve/Reject Withdraw
- Kelola Template Pesan

## Catatan Keamanan

- Semua input divalidasi
- Error handling lengkap
- Auto save database setiap 30 detik
- Auto backup berkala
- Logging lengkap ke file

## Troubleshooting

**Error: EALLOWGIT / Refusing to fetch git**
- Gunakan `setup-pterodactyl.js` (lihat bagian Pterodactyl di atas)

**Error: Cannot find module '@whiskeysockets/baileys'**
- Pastikan `node setup-pterodactyl.js` berhasil dijalankan
- Lalu jalankan `npm install --legacy-peer-deps`

**Error: WhatsApp tidak terhubung**
- Pastikan nomor WA belum terdaftar di perangkat lain
- Coba logout lalu scan QR ulang

## Support

Telegram: @CsSanzDigital
