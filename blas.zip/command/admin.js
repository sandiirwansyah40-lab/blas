const db = require('../utils/database');
const admin = require('../handler/admin');
const blast = require('../handler/blast');
const wa = require('../handler/whatsapp');
const { formatRupiah, escapeHtml, now } = require('../utils/helper');
const logger = require('../utils/logger');
const fs = require('fs-extra');
const path = require('path');

const userStates = new Map();

module.exports = async (bot, query) => {
    const chatId = query.message.chat.id;
    const userId = query.from.id;
    const messageId = query.message.message_id;
    const action = query.data;

    if (!admin.isOwner(userId)) {
        await bot.answerCallbackQuery(query.id, { text: '⛔ Khusus Owner' });
        return;
    }

    if (action === 'admin_menu') {
        const users = Object.keys(db.get('users')).length;
        const activeSessions = Object.values(db.get('sessions')).filter(s => s.status === 'connected').length;
        const pendingWd = Object.values(db.get('withdraw')).filter(w => w.status === 'pending').length;

        const text = 
            `<b>⚙️ Panel Admin</b>

` +
            `👥 <b>Total User :</b> ${users}
` +
            `📱 <b>WA Aktif :</b> ${activeSessions}
` +
            `⏳ <b>WD Pending :</b> ${pendingWd}

` +
            `Pilih menu admin :`;

        const keyboard = {
            inline_keyboard: [
                [
                    { text: '💰 Saldo', callback_data: 'admin_balance' },
                    { text: '💵 Harga', callback_data: 'admin_price' }
                ],
                [
                    { text: '👥 Users', callback_data: 'admin_users' },
                    { text: '📢 Broadcast', callback_data: 'admin_broadcast' }
                ],
                [
                    { text: '⏱ Delay', callback_data: 'admin_delay' },
                    { text: '💸 Min WD', callback_data: 'admin_minwd' }
                ],
                [
                    { text: '🔄 Reset Riwayat', callback_data: 'admin_reset' },
                    { text: '💳 WD Requests', callback_data: 'admin_wd' }
                ],
                [
                    { text: '💾 Backup', callback_data: 'admin_backup' },
                    { text: '📥 Restore', callback_data: 'admin_restore' }
                ],
                [
                    { text: '🚪 Logout All', callback_data: 'admin_logout_all' },
                    { text: '🗑 Hapus Session', callback_data: 'admin_del_session' }
                ],
                [{ text: '◀️ Kembali', callback_data: 'start_menu' }]
            ]
        };

        await bot.editMessageText(text, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: 'HTML',
            reply_markup: keyboard
        });
    }

    else if (action === 'admin_balance') {
        userStates.set(userId, { step: 'admin_balance_user' });

        await bot.editMessageText(
            `<b>💰 Kelola Saldo</b>

` +
            `Format : <code>USERID JUMLAH</code>
` +
            `Contoh tambah : <code>123456789 50000</code>
` +
            `Contoh kurang : <code>123456789 -50000</code>

` +
            `Ketik di chat ini.`,
            {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [[{ text: '❌ Batal', callback_data: 'admin_menu' }]]
                }
            }
        );
    }

    else if (action === 'admin_price') {
        userStates.set(userId, { step: 'admin_price' });
        const current = db.get('settings').price_per_chat || 500;

        await bot.editMessageText(
            `<b>💵 Edit Harga Blast</b>

` +
            `Harga saat ini : ${formatRupiah(current)}/chat

` +
            `Masukkan harga baru :
` +
            `Contoh : <code>1000</code>`,
            {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [[{ text: '❌ Batal', callback_data: 'admin_menu' }]]
                }
            }
        );
    }

    else if (action === 'admin_minwd') {
        userStates.set(userId, { step: 'admin_minwd' });
        const current = db.get('settings').min_withdraw || 50000;

        await bot.editMessageText(
            `<b>💸 Edit Minimum Withdraw</b>

` +
            `Min WD saat ini : ${formatRupiah(current)}

` +
            `Masukkan min WD baru :
` +
            `Contoh : <code>100000</code>`,
            {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [[{ text: '❌ Batal', callback_data: 'admin_menu' }]]
                }
            }
        );
    }

    else if (action === 'admin_delay') {
        userStates.set(userId, { step: 'admin_delay' });
        const current = db.get('settings').default_delay || 5;

        await bot.editMessageText(
            `<b>⏱ Edit Delay Default</b>

` +
            `Delay saat ini : ${current} detik

` +
            `Masukkan delay baru (detik) :
` +
            `Contoh : <code>10</code>`,
            {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [[{ text: '❌ Batal', callback_data: 'admin_menu' }]]
                }
            }
        );
    }

    else if (action === 'admin_users') {
        const users = admin.getUserStats();

        let text = `<b>👥 Daftar User</b>

`;

        if (users.length === 0) {
            text += `Belum ada user.`;
        } else {
            users.forEach((u, i) => {
                text += `${i + 1}. <code>${u.userId}</code>
`;
                text += `   @${escapeHtml(u.username || 'no_username')}
`;
                text += `   💰 ${formatRupiah(u.balance)} | 📂 ${u.contactCount} | 📱 ${u.waStatus}

`;
            });
        }

        await bot.editMessageText(text, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [[{ text: '◀️ Kembali', callback_data: 'admin_menu' }]]
            }
        });
    }

    else if (action === 'admin_broadcast') {
        userStates.set(userId, { step: 'admin_broadcast' });

        await bot.editMessageText(
            `<b>📢 Broadcast</b>

` +
            `Ketik pesan yang akan dibroadcast ke semua user :
` +
            `(Support HTML)`,
            {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [[{ text: '❌ Batal', callback_data: 'admin_menu' }]]
                }
            }
        );
    }

    else if (action === 'admin_reset') {
        await bot.editMessageText(
            `<b>🔄 Reset Riwayat Blast</b>

` +
            `Pilih opsi :`,
            {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '👤 Per User', callback_data: 'admin_reset_user' },
                            { text: '🔥 Semua User', callback_data: 'admin_reset_all' }
                        ],
                        [{ text: '◀️ Kembali', callback_data: 'admin_menu' }]
                    ]
                }
            }
        );
    }

    else if (action === 'admin_reset_user') {
        userStates.set(userId, { step: 'admin_reset_user' });

        await bot.editMessageText(
            `<b>🔄 Reset Per User</b>

` +
            `Masukkan User ID :
` +
            `Contoh : <code>123456789</code>`,
            {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [[{ text: '❌ Batal', callback_data: 'admin_menu' }]]
                }
            }
        );
    }

    else if (action === 'admin_reset_all') {
        blast.resetHistory();

        await bot.editMessageText(
            `<b>✅ Riwayat Direset</b>

` +
            `Riwayat blast semua user telah direset.`,
            {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [[{ text: '◀️ Kembali', callback_data: 'admin_menu' }]]
                }
            }
        );
    }

    else if (action === 'admin_backup') {
        try {
            const backupPath = admin.backup();
            await bot.sendDocument(chatId, backupPath, {
                caption: `<b>💾 Backup Berhasil</b>

Path : ${escapeHtml(backupPath)}`,
                parse_mode: 'HTML'
            });
        } catch (err) {
            await bot.sendMessage(chatId,
                `<b>❌ Backup Gagal</b>

${escapeHtml(err.message)}`,
                { parse_mode: 'HTML' }
            );
        }
    }

    else if (action === 'admin_restore') {
        userStates.set(userId, { step: 'admin_restore' });

        await bot.editMessageText(
            `<b>📥 Restore Database</b>

` +
            `Kirim file backup ZIP atau folder path :
` +
            `Ketik path backup di chat ini.`,
            {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [[{ text: '❌ Batal', callback_data: 'admin_menu' }]]
                }
            }
        );
    }

    else if (action === 'admin_logout_all') {
        await admin.logoutAllSessions();

        await bot.editMessageText(
            `<b>🚪 Logout Semua Session</b>

` +
            `Semua session WhatsApp telah di-logout.`,
            {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [[{ text: '◀️ Kembali', callback_data: 'admin_menu' }]]
                }
            }
        );
    }

    else if (action === 'admin_del_session') {
        userStates.set(userId, { step: 'admin_del_session' });

        await bot.editMessageText(
            `<b>🗑 Hapus Session User</b>

` +
            `Masukkan User ID :
` +
            `Contoh : <code>123456789</code>`,
            {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [[{ text: '❌ Batal', callback_data: 'admin_menu' }]]
                }
            }
        );
    }

    else if (action === 'admin_wd') {
        const withdrawals = Object.values(db.get('withdraw')).filter(w => w.status === 'pending');

        if (withdrawals.length === 0) {
            await bot.editMessageText(
                `<b>💳 Withdraw Requests</b>

` +
                `Tidak ada permintaan withdraw pending.`,
                {
                    chat_id: chatId,
                    message_id: messageId,
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [[{ text: '◀️ Kembali', callback_data: 'admin_menu' }]]
                    }
                }
            );
            return;
        }

        let text = `<b>💳 Withdraw Pending</b>

`;
        const keyboard = { inline_keyboard: [] };

        withdrawals.forEach(w => {
            text += `ID : <code>${w.id}</code>
`;
            text += `User : <code>${w.userId}</code>
`;
            text += `Jumlah : ${formatRupiah(w.amount)}
`;
            text += `Metode : ${escapeHtml(w.method)}
`;
            text += `Waktu : ${escapeHtml(w.requestedAt)}

`;

            keyboard.inline_keyboard.push([
                { text: `✅ ${w.id}`, callback_data: `wd_approve_${w.id}` },
                { text: `❌ ${w.id}`, callback_data: `wd_reject_${w.id}` }
            ]);
        });

        keyboard.inline_keyboard.push([{ text: '◀️ Kembali', callback_data: 'admin_menu' }]);

        await bot.editMessageText(text, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: 'HTML',
            reply_markup: keyboard
        });
    }

    else if (action.startsWith('wd_approve_')) {
        const wdId = action.replace('wd_approve_', '');
        const result = admin.approveWithdraw(wdId, bot);

        if (result) {
            await bot.answerCallbackQuery(query.id, { text: '✅ Withdraw Approved' });
        } else {
            await bot.answerCallbackQuery(query.id, { text: '❌ Gagal approve' });
        }

        // Refresh
        await module.exports(bot, { ...query, data: 'admin_wd' });
    }

    else if (action.startsWith('wd_reject_')) {
        const wdId = action.replace('wd_reject_', '');
        userStates.set(userId, { step: 'wd_reject_reason', wdId });

        await bot.editMessageText(
            `<b>❌ Reject Withdraw</b>

` +
            `ID : <code>${wdId}</code>

` +
            `Masukkan alasan penolakan (opsional) :`,
            {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [[{ text: '❌ Batal', callback_data: 'admin_wd' }]]
                }
            }
        );
    }
};

module.exports.handleText = async (bot, msg) => {
    const userId = msg.from.id;
    const chatId = msg.chat.id;
    const state = userStates.get(userId);

    if (!state) return false;
    if (!admin.isOwner(userId)) return false;

    if (state.step === 'admin_balance_user') {
        const parts = msg.text.trim().split(/\s+/);
        if (parts.length < 2) {
            await bot.sendMessage(chatId, `<b>❌ Format Salah</b>

Format : USERID JUMLAH`, { parse_mode: 'HTML' });
            return true;
        }

        const targetId = parts[0];
        const amount = parseInt(parts[1]);

        if (isNaN(amount)) {
            await bot.sendMessage(chatId, `<b>❌ Jumlah Tidak Valid</b>`, { parse_mode: 'HTML' });
            return true;
        }

        if (amount > 0) {
            admin.addBalance(targetId, amount, 'Ditambahkan owner');
            await bot.sendMessage(chatId,
                `<b>✅ Saldo Ditambahkan</b>

` +
                `User : <code>${targetId}</code>
` +
                `Jumlah : ${formatRupiah(amount)}`,
                { parse_mode: 'HTML' }
            );
        } else {
            admin.reduceBalance(targetId, Math.abs(amount), 'Dikurangi owner');
            await bot.sendMessage(chatId,
                `<b>✅ Saldo Dikurangi</b>

` +
                `User : <code>${targetId}</code>
` +
                `Jumlah : ${formatRupiah(Math.abs(amount))}`,
                { parse_mode: 'HTML' }
            );
        }

        userStates.delete(userId);
        return true;
    }

    else if (state.step === 'admin_price') {
        const price = parseInt(msg.text.trim());
        if (isNaN(price) || price < 1) {
            await bot.sendMessage(chatId, `<b>❌ Harga Tidak Valid</b>`, { parse_mode: 'HTML' });
            return true;
        }

        admin.setPrice(price);
        await bot.sendMessage(chatId,
            `<b>✅ Harga Diperbarui</b>

Harga blast : ${formatRupiah(price)}/chat`,
            { parse_mode: 'HTML' }
        );
        userStates.delete(userId);
        return true;
    }

    else if (state.step === 'admin_minwd') {
        const amount = parseInt(msg.text.trim());
        if (isNaN(amount) || amount < 1) {
            await bot.sendMessage(chatId, `<b>❌ Jumlah Tidak Valid</b>`, { parse_mode: 'HTML' });
            return true;
        }

        admin.setMinWithdraw(amount);
        await bot.sendMessage(chatId,
            `<b>✅ Min WD Diperbarui</b>

Min withdraw : ${formatRupiah(amount)}`,
            { parse_mode: 'HTML' }
        );
        userStates.delete(userId);
        return true;
    }

    else if (state.step === 'admin_delay') {
        const delay = parseInt(msg.text.trim());
        if (isNaN(delay) || delay < 1) {
            await bot.sendMessage(chatId, `<b>❌ Delay Tidak Valid</b>`, { parse_mode: 'HTML' });
            return true;
        }

        admin.setDefaultDelay(delay);
        await bot.sendMessage(chatId,
            `<b>✅ Delay Diperbarui</b>

Delay default : ${delay} detik`,
            { parse_mode: 'HTML' }
        );
        userStates.delete(userId);
        return true;
    }

    else if (state.step === 'admin_broadcast') {
        const message = msg.text;
        const result = admin.broadcast(message, bot);

        await bot.sendMessage(chatId,
            `<b>📢 Broadcast Terkirim</b>

` +
            `Total : ${result.total}
` +
            `Berhasil : ${result.sent}
` +
            `Gagal : ${result.failed}`,
            { parse_mode: 'HTML' }
        );
        userStates.delete(userId);
        return true;
    }

    else if (state.step === 'admin_reset_user') {
        const targetId = msg.text.trim();
        blast.resetHistory(targetId);

        await bot.sendMessage(chatId,
            `<b>✅ Riwayat Direset</b>

User : <code>${targetId}</code>`,
            { parse_mode: 'HTML' }
        );
        userStates.delete(userId);
        return true;
    }

    else if (state.step === 'admin_restore') {
        const backupPath = msg.text.trim();
        const result = admin.restore(backupPath);

        if (result) {
            await bot.sendMessage(chatId,
                `<b>✅ Restore Berhasil</b>

Database telah dipulihkan.`,
                { parse_mode: 'HTML' }
            );
        } else {
            await bot.sendMessage(chatId,
                `<b>❌ Restore Gagal</b>

Path tidak ditemukan.`,
                { parse_mode: 'HTML' }
            );
        }
        userStates.delete(userId);
        return true;
    }

    else if (state.step === 'admin_del_session') {
        const targetId = msg.text.trim();
        await admin.deleteUserSession(targetId);

        await bot.sendMessage(chatId,
            `<b>✅ Session Dihapus</b>

User : <code>${targetId}</code>`,
            { parse_mode: 'HTML' }
        );
        userStates.delete(userId);
        return true;
    }

    else if (state.step === 'wd_reject_reason') {
        const reason = msg.text.trim();
        admin.rejectWithdraw(state.wdId, reason, bot);

        await bot.sendMessage(chatId,
            `<b>✅ Withdraw Ditolak</b>

ID : <code>${state.wdId}</code>`,
            { parse_mode: 'HTML' }
        );
        userStates.delete(userId);
        return true;
    }

    return false;
};
