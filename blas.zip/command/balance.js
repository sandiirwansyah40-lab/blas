const db = require('../utils/database');
const admin = require('../handler/admin');
const { formatRupiah, escapeHtml, now } = require('../utils/helper');
const logger = require('../utils/logger');

const userStates = new Map();

module.exports = async (bot, query) => {
    const chatId = query.message.chat.id;
    const userId = query.from.id;
    const messageId = query.message.message_id;
    const action = query.data;

    if (action === 'balance_menu') {
        const balance = db.getById('balance', userId)?.amount || 0;
        const settings = db.get('settings');
        const minWd = settings.min_withdraw || 50000;
        const history = db.getById('history', userId)?.transactions || [];
        const recentHistory = history.slice(-5).reverse();

        let text = `<b>💰 Saldo & Withdraw</b>

`;
        text += `💵 <b>Saldo :</b> ${formatRupiah(balance)}
`;
        text += `📉 <b>Min WD :</b> ${formatRupiah(minWd)}

`;

        if (recentHistory.length > 0) {
            text += `<b>📊 Riwayat Terakhir :</b>
`;
            recentHistory.forEach(h => {
                const icon = h.amount > 0 ? '➕' : '➖';
                text += `${icon} ${formatRupiah(Math.abs(h.amount))} - ${escapeHtml(h.type)}
`;
            });
            text += `
`;
        }

        text += `Pilih opsi di bawah ini :`;

        const keyboard = {
            inline_keyboard: [
                [{ text: '💸 Request Withdraw', callback_data: 'wd_request' }],
                [{ text: '📊 Semua Riwayat', callback_data: 'wd_history' }],
                [{ text: '◀️ Kembali', callback_data: 'start_menu' }]
            ]
        };

        await bot.editMessageText(text, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: 'HTML',
            reply_markup: keyboard
        });
    }

    else if (action === 'wd_request') {
        const balance = db.getById('balance', userId)?.amount || 0;
        const settings = db.get('settings');
        const minWd = settings.min_withdraw || 50000;

        if (balance < minWd) {
            await bot.answerCallbackQuery(query.id, { 
                text: `❌ Min withdraw ${formatRupiah(minWd)}` 
            });
            return;
        }

        userStates.set(userId, { step: 'wd_amount' });

        await bot.editMessageText(
            `<b>💸 Request Withdraw</b>

` +
            `Saldo Anda : ${formatRupiah(balance)}
` +
            `Min Withdraw : ${formatRupiah(minWd)}

` +
            `Masukkan jumlah withdraw :
` +
            `Contoh : <code>100000</code>`,
            {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [[{ text: '❌ Batal', callback_data: 'balance_menu' }]]
                }
            }
        );
    }

    else if (action === 'wd_history') {
        const history = db.getById('history', userId)?.transactions || [];

        let text = `<b>📊 Riwayat Transaksi</b>

`;

        if (history.length === 0) {
            text += `Belum ada riwayat transaksi.`;
        } else {
            history.slice().reverse().forEach((h, i) => {
                if (i >= 20) return; // Max 20
                const icon = h.amount > 0 ? '➕' : '➖';
                text += `${icon} ${formatRupiah(Math.abs(h.amount))}
`;
                text += `   ${escapeHtml(h.description || h.type)}
`;
                text += `   <i>${escapeHtml(h.date)}</i>

`;
            });
        }

        await bot.editMessageText(text, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [[{ text: '◀️ Kembali', callback_data: 'balance_menu' }]]
            }
        });
    }
};

module.exports.handleText = async (bot, msg) => {
    const userId = msg.from.id;
    const chatId = msg.chat.id;
    const state = userStates.get(userId);

    if (!state) return false;

    if (state.step === 'wd_amount') {
        const amount = parseInt(msg.text.trim().replace(/[^0-9]/g, ''));
        const balance = db.getById('balance', userId)?.amount || 0;
        const settings = db.get('settings');
        const minWd = settings.min_withdraw || 50000;

        if (isNaN(amount) || amount < minWd) {
            await bot.sendMessage(chatId,
                `<b>❌ Jumlah Tidak Valid</b>

` +
                `Minimum withdraw : ${formatRupiah(minWd)}`,
                { parse_mode: 'HTML' }
            );
            return true;
        }

        if (amount > balance) {
            await bot.sendMessage(chatId,
                `<b>❌ Saldo Tidak Cukup</b>

` +
                `Saldo Anda : ${formatRupiah(balance)}`,
                { parse_mode: 'HTML' }
            );
            return true;
        }

        state.step = 'wd_method';
        state.amount = amount;

        await bot.sendMessage(chatId,
            `<b>💸 Withdraw ${formatRupiah(amount)}</b>

` +
            `Masukkan metode pembayaran & nomor rekening :
` +
            `Contoh : <code>DANA - 081234567890</code>`,
            {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [[{ text: '❌ Batal', callback_data: 'balance_menu' }]]
                }
            }
        );
        return true;
    }

    else if (state.step === 'wd_method') {
        const amount = state.amount;
        const method = msg.text.trim();
        const wdId = `WD-${Date.now()}`;

        // Kurangi saldo
        const current = db.getById('balance', userId)?.amount || 0;
        db.setById('balance', userId, {
            userId,
            amount: current - amount,
            updatedAt: now()
        });

        // Simpan withdraw
        db.setById('withdraw', wdId, {
            id: wdId,
            userId,
            amount,
            method,
            status: 'pending',
            requestedAt: now()
        });

        // Simpan history
        db.push('history', userId, 'transactions', {
            type: 'withdraw_request',
            amount: -amount,
            description: `Withdraw ${method}`,
            date: now()
        });

        userStates.delete(userId);

        // Notifikasi ke user
        await bot.sendMessage(chatId,
            `<b>⏳ Withdraw Diajukan</b>

` +
            `ID : <code>${wdId}</code>
` +
            `Jumlah : ${formatRupiah(amount)}
` +
            `Metode : ${escapeHtml(method)}
` +
            `Status : <b>PENDING</b>

` +
            `Owner akan memproses permintaan Anda.`,
            { parse_mode: 'HTML' }
        );

        // Notifikasi ke owner
        const ownerIds = process.env.OWNER_ID ? process.env.OWNER_ID.split(',') : [];
        ownerIds.forEach(async (ownerId) => {
            try {
                await bot.sendMessage(ownerId,
                    `<b>🔔 Withdraw Baru</b>

` +
                    `ID : <code>${wdId}</code>
` +
                    `User : <code>${userId}</code>
` +
                    `Jumlah : ${formatRupiah(amount)}
` +
                    `Metode : ${escapeHtml(method)}
` +
                    `Waktu : ${now()}

` +
                    `Gunakan Panel Admin untuk approve/reject.`,
                    { parse_mode: 'HTML' }
                );
            } catch (e) {}
        });

        logger.info({ msg: 'Withdraw requested', wdId, userId, amount });
        return true;
    }

    return false;
};
