const db = require('../utils/database');
const blast = require('../handler/blast');
const wa = require('../handler/whatsapp');
const admin = require('../handler/admin');
const { formatRupiah, escapeHtml, progressBar } = require('../utils/helper');

const userStates = new Map();
const progressIntervals = new Map();

module.exports = async (bot, query) => {
    const chatId = query.message.chat.id;
    const userId = query.from.id;
    const messageId = query.message.message_id;
    const action = query.data;

    if (action === 'blast_menu') {
        const contacts = db.getById('contacts', userId)?.list || [];
        const templates = Object.values(admin.getTemplates());
        const settings = db.get('settings');
        const balance = db.getById('balance', userId)?.amount || 0;
        const activeBlast = blast.getActiveBlast(userId);

        let text = `<b>🚀 WhatsApp Blast</b>

`;
        text += `📂 <b>Kontak :</b> ${contacts.length.toLocaleString('id-ID')}
`;
        text += `💰 <b>Saldo :</b> ${formatRupiah(balance)}
`;
        text += `💵 <b>Harga :</b> ${formatRupiah(settings.price_per_chat || 500)}/chat

`;

        if (activeBlast) {
            const progress = blast.getProgress(activeBlast.id);
            text += `⏳ <b>Blast Aktif</b>
`;
            text += `📊 ${progressBar(progress.current, progress.total)}
`;
            text += `✅ ${progress.success} | ❌ ${progress.failed} | ⏳ ${progress.remaining}

`;
        }

        text += `Pilih opsi di bawah ini :`;

        const keyboard = { inline_keyboard: [] };

        if (contacts.length > 0 && templates.length > 0) {
            keyboard.inline_keyboard.push([{ text: '🚀 Mulai Blast', callback_data: 'blast_start_menu' }]);
        }

        if (activeBlast) {
            if (activeBlast.status === 'running') {
                keyboard.inline_keyboard.push([
                    { text: '⏸ Pause', callback_data: `blast_pause_${activeBlast.id}` },
                    { text: '⛔ Stop', callback_data: `blast_stop_${activeBlast.id}` }
                ]);
            } else if (activeBlast.status === 'paused') {
                keyboard.inline_keyboard.push([
                    { text: '▶️ Resume', callback_data: `blast_resume_${activeBlast.id}` },
                    { text: '⛔ Stop', callback_data: `blast_stop_${activeBlast.id}` }
                ]);
            }
        }

        keyboard.inline_keyboard.push(
            [{ text: '⚙️ Pengaturan Delay', callback_data: 'blast_delay_menu' }],
            [{ text: '🔄 Reset Riwayat', callback_data: 'blast_reset' }],
            [{ text: '◀️ Kembali', callback_data: 'start_menu' }]
        );

        await bot.editMessageText(text, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: 'HTML',
            reply_markup: keyboard
        });
    }

    else if (action === 'blast_start_menu') {
        const contacts = db.getById('contacts', userId)?.list || [];
        const templates = Object.values(admin.getTemplates());
        const settings = db.get('settings');
        const price = settings.price_per_chat || 500;
        const totalCost = contacts.length * price;
        const balance = db.getById('balance', userId)?.amount || 0;

        if (contacts.length === 0) {
            await bot.answerCallbackQuery(query.id, { text: '❌ Tidak ada kontak' });
            return;
        }

        if (templates.length === 0) {
            await bot.answerCallbackQuery(query.id, { text: '❌ Tidak ada template' });
            return;
        }

        if (balance < totalCost) {
            await bot.answerCallbackQuery(query.id, { text: '❌ Saldo tidak cukup' });
            return;
        }

        if (!wa.isConnected(userId)) {
            await bot.answerCallbackQuery(query.id, { text: '❌ WA belum terhubung' });
            return;
        }

        // Pilih template
        let text = `<b>🚀 Mulai Blast</b>

` +
                   `📂 <b>Total Kontak :</b> ${contacts.length.toLocaleString('id-ID')}
` +
                   `💰 <b>Biaya :</b> ${formatRupiah(totalCost)}
` +
                   `⏱ <b>Delay :</b> ${settings.default_delay || 5} detik

` +
                   `Pilih template pesan :`;

        const keyboard = { inline_keyboard: [] };
        templates.forEach(t => {
            keyboard.inline_keyboard.push([
                { text: escapeHtml(t.name), callback_data: `blast_template_${t.id}` }
            ]);
        });
        keyboard.inline_keyboard.push([{ text: '❌ Batal', callback_data: 'blast_menu' }]);

        await bot.editMessageText(text, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: 'HTML',
            reply_markup: keyboard
        });
    }

    else if (action.startsWith('blast_template_')) {
        const templateId = action.replace('blast_template_', '');
        const contacts = db.getById('contacts', userId)?.list || [];
        const settings = db.get('settings');
        const delay = settings.default_delay || 5;

        userStates.set(userId, { 
            step: 'blast_confirm', 
            templateId, 
            contacts, 
            delay 
        });

        const template = db.getById('message', templateId);

        await bot.editMessageText(
            `<b>🚀 Konfirmasi Blast</b>

` +
            `📂 <b>Total :</b> ${contacts.length.toLocaleString('id-ID')}
` +
            `⏱ <b>Delay :</b> ${delay} detik
` +
            `📝 <b>Template :</b> ${escapeHtml(template?.name || 'Unknown')}

` +
            `Preview :
<blockquote expandable>${escapeHtml(template?.text?.substring(0, 200) || '')}</blockquote>

` +
            `Klik Start untuk memulai :`,
            {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '▶️ START BLAST', callback_data: 'blast_confirm_start' }],
                        [{ text: '⚙️ Ubah Delay', callback_data: 'blast_delay_custom' }],
                        [{ text: '❌ Batal', callback_data: 'blast_menu' }]
                    ]
                }
            }
        );
    }

    else if (action === 'blast_delay_custom') {
        userStates.set(userId, { step: 'blast_delay_input' });

        await bot.editMessageText(
            `<b>⚙️ Custom Delay</b>

` +
            `Masukkan delay dalam detik (1-300) :
` +
            `Contoh : <code>10</code>`,
            {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [[{ text: '❌ Batal', callback_data: 'blast_menu' }]]
                }
            }
        );
    }

    else if (action === 'blast_confirm_start') {
        const state = userStates.get(userId);
        if (!state || state.step !== 'blast_confirm') {
            await bot.answerCallbackQuery(query.id, { text: '❌ Sesi habis' });
            return;
        }

        userStates.delete(userId);

        try {
            const blastData = await blast.startBlast(userId, {
                contacts: state.contacts,
                messageId: state.templateId,
                delay: state.delay || 5
            });

            // Kirim pesan progress
            const progressMsg = await bot.sendMessage(chatId,
                `<b>🚀 Blast Dimulai</b>

` +
                `ID : <code>${blastData.id}</code>
` +
                `Total : ${blastData.total.toLocaleString('id-ID')}
` +
                `Delay : ${blastData.delay} detik

` +
                `Sedang mengirim...`,
                { parse_mode: 'HTML' }
            );

            // Update progress setiap 3 detik
            const interval = setInterval(async () => {
                const progress = blast.getProgress(blastData.id);
                if (!progress || progress.status === 'completed' || progress.status === 'stopped') {
                    clearInterval(interval);
                    progressIntervals.delete(blastData.id);

                    const finalText = progress?.status === 'completed' 
                        ? `<b>✅ Blast Selesai</b>

` +
                          `✅ Berhasil : ${progress.success}
` +
                          `❌ Gagal : ${progress.failed}
` +
                          `📊 Total : ${progress.total}`
                        : `<b>⛔ Blast Dihentikan</b>

` +
                          `✅ Berhasil : ${progress?.success || 0}
` +
                          `❌ Gagal : ${progress?.failed || 0}`;

                    try {
                        await bot.editMessageText(finalText, {
                            chat_id: chatId,
                            message_id: progressMsg.message_id,
                            parse_mode: 'HTML'
                        });
                    } catch (e) {}
                    return;
                }

                try {
                    await bot.editMessageText(
                        `<b>🚀 Blast Berjalan</b>

` +
                        `ID : <code>${blastData.id}</code>
` +
                        `📊 ${progressBar(progress.current, progress.total)}

` +
                        `✅ Berhasil : ${progress.success.toLocaleString('id-ID')}
` +
                        `❌ Gagal : ${progress.failed.toLocaleString('id-ID')}
` +
                        `⏳ Sisa : ${progress.remaining.toLocaleString('id-ID')}
` +
                        `📈 ${progress.percentage}%`,
                        {
                            chat_id: chatId,
                            message_id: progressMsg.message_id,
                            parse_mode: 'HTML',
                            reply_markup: {
                                inline_keyboard: [
                                    [
                                        { text: '⏸ Pause', callback_data: `blast_pause_${blastData.id}` },
                                        { text: '⛔ Stop', callback_data: `blast_stop_${blastData.id}` }
                                    ]
                                ]
                            }
                        }
                    );
                } catch (e) {}
            }, 3000);

            progressIntervals.set(blastData.id, interval);

        } catch (err) {
            await bot.sendMessage(chatId,
                `<b>❌ Gagal Memulai Blast</b>

${escapeHtml(err.message)}`,
                { parse_mode: 'HTML' }
            );
        }
    }

    else if (action.startsWith('blast_pause_')) {
        const blastId = action.replace('blast_pause_', '');
        const result = blast.pauseBlast(blastId);

        if (result) {
            await bot.answerCallbackQuery(query.id, { text: '⏸ Blast Dijeda' });
        } else {
            await bot.answerCallbackQuery(query.id, { text: '❌ Tidak dapat dijeda' });
        }
    }

    else if (action.startsWith('blast_resume_')) {
        const blastId = action.replace('blast_resume_', '');
        const result = blast.resumeBlast(blastId);

        if (result) {
            await bot.answerCallbackQuery(query.id, { text: '▶️ Blast Dilanjutkan' });
        } else {
            await bot.answerCallbackQuery(query.id, { text: '❌ Tidak dapat dilanjutkan' });
        }
    }

    else if (action.startsWith('blast_stop_')) {
        const blastId = action.replace('blast_stop_', '');
        const result = blast.stopBlast(blastId);

        if (progressIntervals.has(blastId)) {
            clearInterval(progressIntervals.get(blastId));
            progressIntervals.delete(blastId);
        }

        if (result) {
            await bot.answerCallbackQuery(query.id, { text: '⛔ Blast Dihentikan' });
        } else {
            await bot.answerCallbackQuery(query.id, { text: '❌ Tidak dapat dihentikan' });
        }
    }

    else if (action === 'blast_delay_menu') {
        const settings = db.get('settings');

        await bot.editMessageText(
            `<b>⚙️ Pengaturan Delay</b>

` +
            `Delay saat ini : ${settings.default_delay || 5} detik

` +
            `Pilih delay :`,
            {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '1 Detik', callback_data: 'blast_delay_1' },
                            { text: '5 Detik', callback_data: 'blast_delay_5' }
                        ],
                        [
                            { text: '10 Detik', callback_data: 'blast_delay_10' },
                            { text: '20 Detik', callback_data: 'blast_delay_20' }
                        ],
                        [
                            { text: '40 Detik', callback_data: 'blast_delay_40' },
                            { text: 'Custom', callback_data: 'blast_delay_custom' }
                        ],
                        [{ text: '◀️ Kembali', callback_data: 'blast_menu' }]
                    ]
                }
            }
        );
    }

    else if (action.startsWith('blast_delay_')) {
        const delay = parseInt(action.replace('blast_delay_', ''));
        const settings = db.get('settings');
        settings.default_delay = delay;
        db.set('settings', settings);

        await bot.answerCallbackQuery(query.id, { text: `✅ Delay diatur ke ${delay} detik` });

        // Refresh menu
        await module.exports(bot, { ...query, data: 'blast_menu' });
    }

    else if (action === 'blast_reset') {
        const history = blast.getUserHistory(userId);

        if (history.sent.length === 0) {
            await bot.answerCallbackQuery(query.id, { text: 'ℹ️ Riwayat sudah kosong' });
            return;
        }

        blast.resetHistory(userId);
        await bot.answerCallbackQuery(query.id, { text: '✅ Riwayat direset' });

        await bot.editMessageText(
            `<b>✅ Riwayat Direset</b>

` +
            `Riwayat blast telah dihapus.
` +
            `Anda dapat mengirim ulang ke nomor yang sama.`,
            {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [[{ text: '◀️ Kembali', callback_data: 'blast_menu' }]]
                }
            }
        );
    }
};

module.exports.handleText = async (bot, msg) => {
    const userId = msg.from.id;
    const chatId = msg.chat.id;
    const state = userStates.get(userId);

    if (!state) return false;

    if (state.step === 'blast_delay_input') {
        const delay = parseInt(msg.text.trim());

        if (isNaN(delay) || delay < 1 || delay > 300) {
            await bot.sendMessage(chatId,
                `<b>❌ Delay Tidak Valid</b>

Masukkan angka 1-300`,
                { parse_mode: 'HTML' }
            );
            return true;
        }

        state.delay = delay;
        state.step = 'blast_confirm';

        await bot.sendMessage(chatId,
            `<b>✅ Delay Diatur</b>

Delay : ${delay} detik

Klik Start untuk memulai blast.`,
            {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '▶️ START BLAST', callback_data: 'blast_confirm_start' }],
                        [{ text: '❌ Batal', callback_data: 'blast_menu' }]
                    ]
                }
            }
        );
        return true;
    }

    return false;
};
