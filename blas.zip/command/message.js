const db = require('../utils/database');
const admin = require('../handler/admin');
const { escapeHtml, generateId } = require('../utils/helper');

const userStates = new Map();

module.exports = async (bot, query) => {
    const chatId = query.message.chat.id;
    const userId = query.from.id;
    const messageId = query.message.message_id;
    const action = query.data;

    if (action === 'message_menu') {
        const templates = Object.values(admin.getTemplates());

        let text = `<b>📝 Template Pesan</b>

`;

        if (templates.length === 0) {
            text += `Belum ada template pesan.

`;
        } else {
            templates.forEach((t, i) => {
                text += `${i + 1}. <b>${escapeHtml(t.name)}</b>
`;
                text += `   ${escapeHtml(t.text.substring(0, 50))}${t.text.length > 50 ? '...' : ''}

`;
            });
        }

        text += `Pilih opsi di bawah ini :`;

        const keyboard = { inline_keyboard: [] };

        if (admin.isOwner(userId)) {
            keyboard.inline_keyboard.push(
                [{ text: '➕ Tambah Template', callback_data: 'msg_add' }],
                [{ text: '🗑 Hapus Template', callback_data: 'msg_delete_menu' }]
            );
        }

        keyboard.inline_keyboard.push([{ text: '◀️ Kembali', callback_data: 'start_menu' }]);

        await bot.editMessageText(text, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: 'HTML',
            reply_markup: keyboard
        });
    }

    else if (action === 'msg_add') {
        if (!admin.isOwner(userId)) {
            await bot.answerCallbackQuery(query.id, { text: '⛔ Khusus Owner' });
            return;
        }

        userStates.set(userId, { step: 'msg_name' });

        await bot.editMessageText(
            `<b>➕ Tambah Template</b>

` +
            `Langkah 1/2 : Masukkan nama template
` +
            `Contoh : Promo Agustus`,
            {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [[{ text: '❌ Batal', callback_data: 'message_menu' }]]
                }
            }
        );
    }

    else if (action === 'msg_delete_menu') {
        if (!admin.isOwner(userId)) {
            await bot.answerCallbackQuery(query.id, { text: '⛔ Khusus Owner' });
            return;
        }

        const templates = Object.values(admin.getTemplates());
        const keyboard = { inline_keyboard: [] };

        templates.forEach(t => {
            keyboard.inline_keyboard.push([
                { text: `🗑 ${escapeHtml(t.name)}`, callback_data: `msg_del_${t.id}` }
            ]);
        });

        keyboard.inline_keyboard.push([{ text: '◀️ Kembali', callback_data: 'message_menu' }]);

        await bot.editMessageText(
            `<b>🗑 Hapus Template</b>

Pilih template yang akan dihapus :`,
            { chat_id: chatId, message_id: messageId, parse_mode: 'HTML', reply_markup: keyboard }
        );
    }

    else if (action.startsWith('msg_del_')) {
        if (!admin.isOwner(userId)) {
            await bot.answerCallbackQuery(query.id, { text: '⛔ Khusus Owner' });
            return;
        }

        const templateId = action.replace('msg_del_', '');
        admin.deleteTemplate(templateId);

        await bot.editMessageText(
            `<b>✅ Template Dihapus</b>`,
            {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [[{ text: '◀️ Kembali', callback_data: 'message_menu' }]]
                }
            }
        );
    }
};

module.exports.handleText = async (bot, msg) => {
    const userId = msg.from.id;
    const chatId = msg.chat.id;
    const state = userStates.get(userId);

    if (!state) return false;

    if (state.step === 'msg_name') {
        state.name = msg.text.trim();
        state.step = 'msg_text';

        await bot.sendMessage(chatId,
            `<b>➕ Tambah Template</b>

` +
            `Langkah 2/2 : Masukkan isi pesan

` +
            `Anda dapat menggunakan :
` +
            `• HTML Tags
` +
            `• Emoji
` +
            `• Format bebas`,
            {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [[{ text: '❌ Batal', callback_data: 'message_menu' }]]
                }
            }
        );
        return true;
    }

    else if (state.step === 'msg_text') {
        const name = state.name;
        const text = msg.text;

        userStates.delete(userId);

        const id = admin.addTemplate(name, text);

        await bot.sendMessage(chatId,
            `<b>✅ Template Ditambahkan</b>

` +
            `ID : <code>${id}</code>
` +
            `Nama : ${escapeHtml(name)}

` +
            `Preview :
${text.substring(0, 200)}`,
            { parse_mode: 'HTML' }
        );
        return true;
    }

    return false;
};
