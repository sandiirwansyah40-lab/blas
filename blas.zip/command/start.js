const db = require('../utils/database');
const { formatRupiah, escapeHtml } = require('../utils/helper');
const wa = require('../handler/whatsapp');
const admin = require('../handler/admin');

module.exports = async (bot, msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const username = msg.from.username || msg.from.first_name || 'User';

    // Register user
    if (!db.getById('users', userId)) {
        db.setById('users', userId, {
            userId,
            username,
            firstName: msg.from.first_name || '',
            lastName: msg.from.last_name || '',
            joinedAt: new Date().toISOString()
        });

        if (!db.getById('balance', userId)) {
            db.setById('balance', userId, { amount: 0, updatedAt: new Date().toISOString() });
        }
    }

    const balance = db.getById('balance', userId)?.amount || 0;
    const session = wa.getSession(userId);
    const contacts = db.getById('contacts', userId)?.list || [];
    const settings = db.get('settings');

    // Hitung blast hari ini
    const today = new Date().toISOString().split('T')[0];
    const blasts = db.get('blast');
    const todayBlasts = Object.values(blasts).filter(b => 
        b.userId === userId && b.startedAt && b.startedAt.startsWith(today)
    );
    const todayCount = todayBlasts.reduce((sum, b) => sum + (b.success || 0), 0);

    const waStatus = session?.status === 'connected' 
        ? '<b>🟢 Terhubung</b>' 
        : '<b>🔴 Terputus</b>';
    const waPhone = session?.phone ? `(${escapeHtml(session.phone)})` : '';

    const text = 
        `<blockquote expandable>📢 Selamat datang di WhatsApp Blaster</blockquote>

` +
        `<b>🚀 WhatsApp Blaster</b>
` +
        `━━━━━━━━━━━━━━

` +
        `👤 <b>User :</b> ${escapeHtml(username)}
` +
        `💰 <b>Saldo :</b> ${formatRupiah(balance)}
` +
        `📱 <b>Status WA :</b> ${waStatus} ${waPhone}
` +
        `📂 <b>Jumlah Nomor :</b> ${contacts.length.toLocaleString('id-ID')}
` +
        `📤 <b>Blast Hari Ini :</b> ${todayCount.toLocaleString('id-ID')}

` +
        `━━━━━━━━━━━━━━
` +
        `💵 <b>Harga :</b> ${formatRupiah(settings.price_per_chat || 500)}/chat
` +
        `⏱ <b>Delay Default :</b> ${settings.default_delay || 5} detik

` +
        `Silakan pilih menu di bawah ini :`;

    const keyboard = {
        inline_keyboard: [
            [
                { text: '📱 Hubungkan WA', callback_data: 'wa_menu' },
                { text: '📤 Upload Kontak', callback_data: 'upload_menu' }
            ],
            [
                { text: '📝 Template Pesan', callback_data: 'message_menu' },
                { text: '🚀 Blast', callback_data: 'blast_menu' }
            ],
            [
                { text: '💰 Saldo & WD', callback_data: 'balance_menu' },
                { text: '📊 Riwayat', callback_data: 'history_menu' }
            ]
        ]
    };

    if (admin.isOwner(userId)) {
        keyboard.inline_keyboard.push([
            { text: '⚙️ Panel Admin', callback_data: 'admin_menu' }
        ]);
    }

    await bot.sendMessage(chatId, text, {
        parse_mode: 'HTML',
        reply_markup: keyboard
    });
};
