const db = require('../utils/database');
const upload = require('../handler/upload');
const { escapeHtml } = require('../utils/helper');

module.exports = async (bot, query) => {
    const chatId = query.message.chat.id;
    const userId = query.from.id;
    const messageId = query.message.message_id;
    const action = query.data;

    if (action === 'upload_menu') {
        const contacts = db.getById('contacts', userId)?.list || [];

        const text = 
            `<b>📤 Upload Kontak</b>

` +
            `Format yang didukung :
` +
            `• <code>.txt</code> - Nomor per baris
` +
            `• <code>.csv</code> - File CSV
` +
            `• <code>.xls / .xlsx</code> - Excel
` +
            `• <code>.pdf</code> - PDF (ekstrak nomor)
` +
            `• <code>.zip</code> - ZIP (berisi file di atas)
` +
            `• <code>.vcf</code> - Kontak VCF

` +
            `📂 <b>Jumlah Kontak :</b> ${contacts.length.toLocaleString('id-ID')}

` +
            `Kirim file ke bot ini untuk mengupload.`;

        const keyboard = {
            inline_keyboard: [
                [{ text: '🗑 Hapus Semua Kontak', callback_data: 'upload_clear' }],
                [{ text: '◀️ Kembali', callback_data: 'start_menu' }]
            ]
        };

        await bot.editMessageText(text, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: 'HTML',
            reply_markup: keyboard
        });
    }

    else if (action === 'upload_clear') {
        upload.clearContacts(userId);
        await bot.editMessageText(
            `<b>🗑 Kontak Dihapus</b>

Semua kontak telah dihapus.`,
            {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [[{ text: '◀️ Kembali', callback_data: 'upload_menu' }]]
                }
            }
        );
    }
};

module.exports.handleDocument = async (bot, msg) => {
    const userId = msg.from.id;
    const chatId = msg.chat.id;
    const doc = msg.document;

    const allowedMime = [
        'text/plain', 'text/csv', 'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/pdf', 'application/zip', 'text/x-vcard',
        'application/vcard'
    ];

    const allowedExt = ['.txt', '.csv', '.xls', '.xlsx', '.pdf', '.zip', '.vcf'];
    const ext = doc.file_name.toLowerCase().substring(doc.file_name.lastIndexOf('.'));

    if (!allowedExt.includes(ext) && !allowedMime.includes(doc.mime_type)) {
        await bot.sendMessage(chatId,
            `<b>❌ Format Tidak Didukung</b>

` +
            `Kirim file dengan format : txt, csv, xls, xlsx, pdf, zip, vcf`,
            { parse_mode: 'HTML' }
        );
        return;
    }

    const statusMsg = await bot.sendMessage(chatId,
        `<b>⏳ Memproses File...</b>

Sedang membaca dan mengekstrak nomor.`,
        { parse_mode: 'HTML' }
    );

    try {
        const file = await bot.getFile(doc.file_id);
        const fileUrl = `https://api.telegram.org/file/bot${process.env.BOT_TOKEN}/${file.file_path}`;
        const axios = require('axios');
        const fs = require('fs-extra');
        const path = require('path');

        const response = await axios.get(fileUrl, { responseType: 'arraybuffer' });
        const tempPath = path.join(__dirname, '..', 'uploads', `${userId}_${Date.now()}${ext}`);
        await fs.writeFile(tempPath, response.data);

        const result = await upload.processFile(tempPath, doc.file_name);
        const saved = upload.saveContacts(userId, result.phones);

        await bot.editMessageText(
            `<b>✅ Upload Berhasil</b>

` +
            `📄 <b>File :</b> ${escapeHtml(doc.file_name)}
` +
            `📊 <b>Total Ditemukan :</b> ${result.original.toLocaleString('id-ID')}
` +
            `✅ <b>Valid :</b> ${result.valid.toLocaleString('id-ID')}
` +
            `❌ <b>Duplikat :</b> ${result.duplicates.toLocaleString('id-ID')}
` +
            `💾 <b>Tersimpan :</b> ${saved.toLocaleString('id-ID')}

` +
            `Total kontak Anda sekarang : ${saved.toLocaleString('id-ID')}`,
            {
                chat_id: chatId,
                message_id: statusMsg.message_id,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [[{ text: '◀️ Kembali ke Menu', callback_data: 'start_menu' }]]
                }
            }
        );
    } catch (err) {
        await bot.editMessageText(
            `<b>❌ Gagal Memproses</b>

${escapeHtml(err.message)}`,
            { chat_id: chatId, message_id: statusMsg.message_id, parse_mode: 'HTML' }
        );
    }
};
