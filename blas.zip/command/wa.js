const db = require('../utils/database');
const wa = require('../handler/whatsapp');
const logger = require('../utils/logger');
const { escapeHtml } = require('../utils/helper');

const userStates = new Map();

module.exports = async (bot, query) => {
    const chatId = query.message.chat.id;
    const userId = query.from.id;
    const messageId = query.message.message_id;

    const action = query.data;

    if (action === 'wa_menu') {
        const session = wa.getSession(userId);
        const isConnected = session?.status === 'connected';

        let text = `<b>📱 WhatsApp Connection</b>

`;

        if (isConnected) {
            text += `✅ <b>Status :</b> Terhubung
`;
            text += `📞 <b>Nomor :</b> +${escapeHtml(session.phone)}
`;
            text += `⏰ <b>Terhubung :</b> ${session.connectedAt}

`;
            text += `Pilih opsi di bawah ini :`;
        } else {
            text += `❌ <b>Status :</b> Tidak Terhubung

`;
            text += `Silakan hubungkan WhatsApp Anda terlebih dahulu.`;
        }

        const keyboard = isConnected ? {
            inline_keyboard: [
                [{ text: '🔄 Reconnect', callback_data: 'wa_reconnect' }],
                [{ text: '🚪 Logout', callback_data: 'wa_logout' }],
                [{ text: '◀️ Kembali', callback_data: 'start_menu' }]
            ]
        } : {
            inline_keyboard: [
                [{ text: '📷 Scan QR Code', callback_data: 'wa_qr' }],
                [{ text: '🔢 Pairing Code', callback_data: 'wa_pairing' }],
                [{ text: '◀️ Kembali', callback_data: 'start_menu' }]
            ]
        };

        await bot.editMessageText(text, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: 'HTML',
            reply_markup: keyboard
        });
    }

    else if (action === 'wa_qr') {
        await bot.editMessageText(
            `<b>📷 Scan QR Code</b>

` +
            `Sedang menghubungkan ke WhatsApp...
` +
            `QR Code akan muncul dalam beberapa detik.`,
            { chat_id: chatId, message_id: messageId, parse_mode: 'HTML' }
        );

        try {
            wa.onQR(userId, async (data) => {
                if (data.type === 'qr') {
                    await bot.sendPhoto(chatId, data.data, {
                        caption: `<b>📷 Scan QR Code</b>

` +
                                `Scan QR code ini dengan WhatsApp Anda.
` +
                                `Buka WhatsApp → Pengaturan → Perangkat Tertaut → Tautkan Perangkat`,
                        parse_mode: 'HTML'
                    });
                } else if (data.type === 'connected') {
                    await bot.sendMessage(chatId,
                        `<b>✅ WhatsApp Terhubung!</b>

` +
                        `Nomor : +${escapeHtml(data.phone)}
` +
                        `Anda sekarang dapat menggunakan fitur blast.`,
                        { parse_mode: 'HTML' }
                    );
                }
            });

            await wa.createSession(userId, 'qr');
        } catch (err) {
            await bot.sendMessage(chatId,
                `<b>❌ Gagal Menghubungkan</b>

${escapeHtml(err.message)}`,
                { parse_mode: 'HTML' }
            );
        }
    }

    else if (action === 'wa_pairing') {
        userStates.set(userId, { step: 'pairing_phone' });

        await bot.editMessageText(
            `<b>🔢 Pairing Code</b>

` +
            `Masukkan nomor WhatsApp Anda dengan format :
` +
            `<code>6281234567890</code>

` +
            `Ketik nomor di chat ini.`,
            { 
                chat_id: chatId, 
                message_id: messageId, 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [[{ text: '❌ Batal', callback_data: 'wa_menu' }]]
                }
            }
        );
    }

    else if (action === 'wa_reconnect') {
        await bot.sendMessage(chatId,
            `<b>🔄 Reconnecting...</b>

Sedang menghubungkan ulang ke WhatsApp.`,
            { parse_mode: 'HTML' }
        );

        try {
            await wa.createSession(userId, 'qr');
        } catch (err) {
            await bot.sendMessage(chatId,
                `<b>❌ Gagal Reconnect</b>

${escapeHtml(err.message)}`,
                { parse_mode: 'HTML' }
            );
        }
    }

    else if (action === 'wa_logout') {
        await bot.editMessageText(
            `<b>🚪 Logout WhatsApp</b>

` +
            `Anda yakin ingin logout?
` +
            `Session akan dihapus permanen.`,
            {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '✅ Ya, Logout', callback_data: 'wa_logout_confirm' },
                            { text: '❌ Batal', callback_data: 'wa_menu' }
                        ]
                    ]
                }
            }
        );
    }

    else if (action === 'wa_logout_confirm') {
        try {
            await wa.logout(userId);
            await bot.editMessageText(
                `<b>✅ Berhasil Logout</b>

Session WhatsApp telah dihapus.`,
                { chat_id: chatId, message_id: messageId, parse_mode: 'HTML' }
            );
        } catch (err) {
            await bot.editMessageText(
                `<b>❌ Gagal Logout</b>

${escapeHtml(err.message)}`,
                { chat_id: chatId, message_id: messageId, parse_mode: 'HTML' }
            );
        }
    }
};

module.exports.handleText = async (bot, msg) => {
    const userId = msg.from.id;
    const chatId = msg.chat.id;
    const state = userStates.get(userId);

    if (!state) return false;

    if (state.step === 'pairing_phone') {
        const phone = msg.text.trim().replace(/[^0-9]/g, '');

        if (phone.length < 10) {
            await bot.sendMessage(chatId,
                `<b>❌ Nomor Tidak Valid</b>

Masukkan nomor yang valid.`,
                { parse_mode: 'HTML' }
            );
            return true;
        }

        userStates.delete(userId);

        await bot.sendMessage(chatId,
            `<b>🔢 Generating Pairing Code...</b>

` +
            `Sedang membuat kode pairing untuk +${escapeHtml(phone)}`,
            { parse_mode: 'HTML' }
        );

        try {
            wa.onPairing(userId, async (data) => {
                if (data.type === 'pairing') {
                    await bot.sendMessage(chatId,
                        `<b>🔢 Pairing Code</b>

` +
                        `<code>${escapeHtml(data.code)}</code>

` +
                        `Buka WhatsApp → Pengaturan → Perangkat Tertaut → Tautkan dengan nomor telepon
` +
                        `Masukkan kode di atas.`,
                        { parse_mode: 'HTML' }
                    );
                } else if (data.type === 'connected') {
                    await bot.sendMessage(chatId,
                        `<b>✅ WhatsApp Terhubung!</b>

` +
                        `Nomor : +${escapeHtml(data.phone)}`,
                        { parse_mode: 'HTML' }
                    );
                } else if (data.type === 'error') {
                    await bot.sendMessage(chatId,
                        `<b>❌ Error</b>

${escapeHtml(data.message)}`,
                        { parse_mode: 'HTML' }
                    );
                }
            });

            await wa.createSession(userId, 'pairing', phone);
        } catch (err) {
            await bot.sendMessage(chatId,
                `<b>❌ Gagal</b>

${escapeHtml(err.message)}`,
                { parse_mode: 'HTML' }
            );
        }
        return true;
    }

    return false;
};
