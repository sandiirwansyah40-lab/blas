const db = require('../utils/database');
const logger = require('../utils/logger');
const { now, formatRupiah } = require('../utils/helper');
const wa = require('./whatsapp');

class AdminHandler {
    constructor() {
        this.ownerIds = process.env.OWNER_ID ? process.env.OWNER_ID.split(',').map(id => id.trim()) : [];
    }

    isOwner(userId) {
        return this.ownerIds.includes(userId.toString());
    }

    addOwner(userId, name = 'Owner') {
        db.setById('owner', userId, {
            userId,
            name,
            addedAt: now(),
            role: 'owner'
        });

        if (!this.ownerIds.includes(userId.toString())) {
            this.ownerIds.push(userId.toString());
        }

        logger.info({ msg: 'Owner added', userId });
    }

    addBalance(userId, amount, note = '') {
        const current = db.getById('balance', userId)?.amount || 0;
        const newBalance = current + amount;

        db.setById('balance', userId, {
            userId,
            amount: newBalance,
            updatedAt: now()
        });

        db.push('history', userId, 'transactions', {
            type: 'add_balance',
            amount,
            note: note || 'Penambahan saldo oleh owner',
            date: now()
        });

        logger.info({ msg: 'Balance added', userId, amount, newBalance });
        return newBalance;
    }

    reduceBalance(userId, amount, note = '') {
        const current = db.getById('balance', userId)?.amount || 0;
        const newBalance = Math.max(0, current - amount);

        db.setById('balance', userId, {
            userId,
            amount: newBalance,
            updatedAt: now()
        });

        db.push('history', userId, 'transactions', {
            type: 'reduce_balance',
            amount: -amount,
            note: note || 'Pengurangan saldo oleh owner',
            date: now()
        });

        logger.info({ msg: 'Balance reduced', userId, amount, newBalance });
        return newBalance;
    }

    setPrice(price) {
        const settings = db.get('settings');
        settings.price_per_chat = parseInt(price);
        settings.updatedAt = now();
        db.set('settings', settings);
        logger.info({ msg: 'Price updated', price });
    }

    setMinWithdraw(amount) {
        const settings = db.get('settings');
        settings.min_withdraw = parseInt(amount);
        settings.updatedAt = now();
        db.set('settings', settings);
        logger.info({ msg: 'Min withdraw updated', amount });
    }

    setDefaultDelay(delay) {
        const settings = db.get('settings');
        settings.default_delay = parseInt(delay);
        settings.updatedAt = now();
        db.set('settings', settings);
        logger.info({ msg: 'Default delay updated', delay });
    }

    getAllUsers() {
        return db.get('users');
    }

    getUserStats() {
        const users = db.get('users');
        const balances = db.get('balance');
        const contacts = db.get('contacts');
        const sessions = db.get('sessions');

        return Object.values(users).map(user => ({
            ...user,
            balance: balances[user.userId]?.amount || 0,
            contactCount: contacts[user.userId]?.list?.length || 0,
            waStatus: sessions[user.userId]?.status || 'disconnected'
        }));
    }

    broadcast(message, bot) {
        const users = db.get('users');
        const settings = db.get('settings');
        settings.broadcast_message = message;
        db.set('settings', settings);

        let sent = 0;
        let failed = 0;

        Object.keys(users).forEach(async (userId) => {
            try {
                await bot.sendMessage(userId, message, { parse_mode: 'HTML' });
                sent++;
            } catch (err) {
                failed++;
            }
        });

        logger.info({ msg: 'Broadcast sent', total: Object.keys(users).length, sent, failed });
        return { sent, failed, total: Object.keys(users).length };
    }

    resetBlastHistory(userId = null) {
        const blast = require('./blast');
        if (userId) {
            blast.resetHistory(userId);
        } else {
            const allHistory = db.get('blast_history');
            Object.keys(allHistory).forEach(id => blast.resetHistory(id));
        }
        logger.info({ msg: 'Blast history reset', userId: userId || 'all' });
    }

    backup() {
        return db.backup();
    }

    restore(backupPath) {
        return db.restore(backupPath);
    }

    async logoutAllSessions() {
        const sessions = db.get('sessions');
        for (const userId of Object.keys(sessions)) {
            try {
                await wa.logout(userId);
            } catch (e) {}
        }
        logger.info({ msg: 'All sessions logged out' });
    }

    async deleteUserSession(userId) {
        await wa.logout(userId);
        logger.info({ msg: 'User session deleted', userId });
    }

    getWithdrawRequests() {
        return db.get('withdraw');
    }

    approveWithdraw(withdrawId, bot) {
        const withdraw = db.getById('withdraw', withdrawId);
        if (!withdraw) return false;

        withdraw.status = 'approved';
        withdraw.approvedAt = now();
        db.setById('withdraw', withdrawId, withdraw);

        // Notifikasi ke user
        bot.sendMessage(withdraw.userId, 
            `<b>✅ Withdraw Disetujui</b>

` +
            `Jumlah: ${formatRupiah(withdraw.amount)}
` +
            `Status: <b>APPROVED</b>
` +
            `Waktu: ${now()}`,
            { parse_mode: 'HTML' }
        );

        logger.info({ msg: 'Withdraw approved', withdrawId, userId: withdraw.userId });
        return true;
    }

    rejectWithdraw(withdrawId, reason = '', bot) {
        const withdraw = db.getById('withdraw', withdrawId);
        if (!withdraw) return false;

        // Kembalikan saldo
        const current = db.getById('balance', withdraw.userId)?.amount || 0;
        db.setById('balance', withdraw.userId, {
            userId: withdraw.userId,
            amount: current + withdraw.amount,
            updatedAt: now()
        });

        withdraw.status = 'rejected';
        withdraw.rejectedAt = now();
        withdraw.reason = reason;
        db.setById('withdraw', withdrawId, withdraw);

        // Notifikasi ke user
        bot.sendMessage(withdraw.userId,
            `<b>❌ Withdraw Ditolak</b>

` +
            `Jumlah: ${formatRupiah(withdraw.amount)}
` +
            `Alasan: ${reason || 'Tidak ada alasan'}
` +
            `Saldo telah dikembalikan.`,
            { parse_mode: 'HTML' }
        );

        logger.info({ msg: 'Withdraw rejected', withdrawId, userId: withdraw.userId });
        return true;
    }

    addTemplate(name, text, media = null) {
        const id = require('../utils/helper').generateId('TMPL-');
        db.setById('message', id, {
            id,
            name,
            text,
            media,
            createdAt: now()
        });
        return id;
    }

    deleteTemplate(id) {
        db.deleteById('message', id);
    }

    getTemplates() {
        return db.get('message');
    }
}

module.exports = new AdminHandler();
