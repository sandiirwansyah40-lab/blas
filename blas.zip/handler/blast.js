const db = require('../utils/database');
const logger = require('../utils/logger');
const wa = require('./whatsapp');
const { sleep, now, generateId, cleanPhone } = require('../utils/helper');

const activeBlasts = new Map();

class BlastHandler {
    constructor() {
        this.blasts = activeBlasts;
    }

    async startBlast(userId, options = {}) {
        const { contacts, messageId, delay = 5, media = null } = options;

        if (!wa.isConnected(userId)) {
            throw new Error('WhatsApp belum terhubung. Hubungkan WhatsApp terlebih dahulu.');
        }

        const user = db.getById('users', userId);
        const settings = db.get('settings');
        const price = settings.price_per_chat || 500;
        const totalCost = contacts.length * price;
        const balance = db.getById('balance', userId)?.amount || 0;

        if (balance < totalCost) {
            throw new Error(`Saldo tidak cukup. Dibutuhkan ${totalCost}, saldo Anda ${balance}`);
        }

        // Cek riwayat blast untuk anti kirim ulang
        const history = db.getById('blast_history', userId)?.sent || [];
        const filteredContacts = contacts.filter(c => !history.includes(c));

        if (filteredContacts.length === 0) {
            throw new Error('Semua nomor sudah pernah dikirim. Reset riwayat terlebih dahulu.');
        }

        const blastId = generateId('BLAST-');
        const blastData = {
            id: blastId,
            userId,
            total: filteredContacts.length,
            success: 0,
            failed: 0,
            sent: [],
            failedList: [],
            status: 'running',
            currentIndex: 0,
            delay,
            messageId,
            media,
            startedAt: now(),
            pausedAt: null,
            completedAt: null
        };

        db.setById('blast', blastId, blastData);
        activeBlasts.set(blastId, blastData);

        // Potong saldo
        const newBalance = balance - totalCost;
        db.setById('balance', userId, { amount: newBalance, updatedAt: now() });

        // Simpan history transaksi
        db.push('history', userId, 'transactions', {
            type: 'blast_payment',
            amount: -totalCost,
            blastId,
            description: `Pembayaran blast ${filteredContacts.length} nomor`,
            date: now()
        });

        // Ambil template pesan
        const template = db.getById('message', messageId);
        if (!template && !media) {
            throw new Error('Template pesan tidak ditemukan');
        }

        const messageText = template ? template.text : (media?.caption || '');

        // Mulai blast
        this.processBlast(blastId, filteredContacts, messageText, media, delay);

        return blastData;
    }

    async processBlast(blastId, contacts, messageText, media, delayMs) {
        const blast = activeBlasts.get(blastId);
        if (!blast) return;

        const delayInMs = delayMs * 1000;

        for (let i = blast.currentIndex; i < contacts.length; i++) {
            const blastCurrent = activeBlasts.get(blastId);
            if (!blastCurrent || blastCurrent.status === 'stopped') {
                break;
            }

            if (blastCurrent.status === 'paused') {
                blastCurrent.pausedAt = now();
                db.setById('blast', blastId, blastCurrent);
                break;
            }

            const phone = cleanPhone(contacts[i]);

            try {
                await wa.sendMessage(blast.userId, phone, messageText, media);

                blast.success++;
                blast.sent.push(phone);

                // Simpan ke riwayat anti kirim ulang
                const history = db.getById('blast_history', blast.userId) || { sent: [] };
                history.sent.push(phone);
                db.setById('blast_history', blast.userId, history);

                logger.info({ msg: 'Blast sent', blastId, phone, index: i });
            } catch (err) {
                blast.failed++;
                blast.failedList.push({ phone, error: err.message });
                logger.error({ msg: 'Blast failed', blastId, phone, error: err.message });
            }

            blast.currentIndex = i + 1;
            activeBlasts.set(blastId, blast);
            db.setById('blast', blastId, blast);

            if (i < contacts.length - 1 && delayInMs > 0) {
                await sleep(delayInMs);
            }
        }

        // Selesai
        const finalBlast = activeBlasts.get(blastId);
        if (finalBlast && finalBlast.status !== 'paused' && finalBlast.status !== 'stopped') {
            finalBlast.status = 'completed';
            finalBlast.completedAt = now();
            db.setById('blast', blastId, finalBlast);
            activeBlasts.delete(blastId);

            logger.info({ msg: 'Blast completed', blastId, total: finalBlast.total, success: finalBlast.success });
        }
    }

    pauseBlast(blastId) {
        const blast = activeBlasts.get(blastId);
        if (blast && blast.status === 'running') {
            blast.status = 'paused';
            blast.pausedAt = now();
            db.setById('blast', blastId, blast);
            return true;
        }
        return false;
    }

    resumeBlast(blastId) {
        const blast = activeBlasts.get(blastId);
        if (blast && blast.status === 'paused') {
            blast.status = 'running';
            blast.pausedAt = null;
            db.setById('blast', blastId, blast);
            activeBlasts.set(blastId, blast);

            // Ambil data
            const userId = blast.userId;
            const contacts = this.getRemainingContacts(blastId);
            const template = db.getById('message', blast.messageId);
            const messageText = template ? template.text : '';
            const media = blast.media;
            const delay = blast.delay;

            this.processBlast(blastId, contacts, messageText, media, delay);
            return true;
        }
        return false;
    }

    stopBlast(blastId) {
        const blast = activeBlasts.get(blastId);
        if (blast) {
            blast.status = 'stopped';
            blast.completedAt = now();
            db.setById('blast', blastId, blast);
            activeBlasts.delete(blastId);
            return true;
        }
        return false;
    }

    getRemainingContacts(blastId) {
        const blast = db.getById('blast', blastId);
        if (!blast) return [];

        const allContacts = db.getById('contacts', blast.userId)?.list || [];
        const sent = blast.sent || [];
        return allContacts.filter(c => !sent.includes(cleanPhone(c)));
    }

    getProgress(blastId) {
        const blast = activeBlasts.get(blastId) || db.getById('blast', blastId);
        if (!blast) return null;

        const total = blast.total || 0;
        const current = blast.currentIndex || 0;
        const success = blast.success || 0;
        const failed = blast.failed || 0;
        const remaining = total - current;
        const percentage = total > 0 ? Math.round((current / total) * 100) : 0;

        return {
            ...blast,
            remaining,
            percentage,
            current
        };
    }

    getActiveBlast(userId) {
        for (const [id, blast] of activeBlasts) {
            if (blast.userId === userId) {
                return blast;
            }
        }
        return null;
    }

    resetHistory(userId) {
        db.setById('blast_history', userId, { sent: [] });
        logger.info({ msg: 'Blast history reset', userId });
    }

    getUserHistory(userId) {
        return db.getById('blast_history', userId) || { sent: [] };
    }
}

module.exports = new BlastHandler();
