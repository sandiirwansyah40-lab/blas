const fs = require('fs-extra');
const path = require('path');
const xlsx = require('xlsx');
const csv = require('csv-parser');
const pdfParse = require('pdf-parse');
const AdmZip = require('adm-zip');
const vcf = require('vcf');
const logger = require('../utils/logger');
const { cleanPhone, validatePhone } = require('../utils/helper');

class UploadHandler {
    constructor() {
        this.uploadDir = path.join(__dirname, '..', 'uploads');
        this.tempDir = path.join(__dirname, '..', 'temp');
        fs.ensureDirSync(this.uploadDir);
        fs.ensureDirSync(this.tempDir);
    }

    async processFile(filePath, originalName) {
        const ext = path.extname(originalName).toLowerCase();
        let phones = [];

        try {
            switch (ext) {
                case '.txt':
                    phones = await this.parseTXT(filePath);
                    break;
                case '.csv':
                    phones = await this.parseCSV(filePath);
                    break;
                case '.xls':
                case '.xlsx':
                    phones = await this.parseExcel(filePath);
                    break;
                case '.pdf':
                    phones = await this.parsePDF(filePath);
                    break;
                case '.zip':
                    phones = await this.parseZIP(filePath);
                    break;
                case '.vcf':
                    phones = await this.parseVCF(filePath);
                    break;
                default:
                    throw new Error(`Format file ${ext} tidak didukung`);
            }
        } catch (err) {
            logger.error({ msg: 'Parse file error', file: originalName, error: err.message });
            throw err;
        } finally {
            // Bersihkan file upload
            if (fs.existsSync(filePath)) {
                fs.removeSync(filePath);
            }
        }

        // Bersihkan dan validasi
        const cleaned = phones
            .map(p => cleanPhone(p))
            .filter(p => validatePhone(p))
            .filter((v, i, a) => a.indexOf(v) === i); // Hapus duplikat

        return {
            original: phones.length,
            valid: cleaned.length,
            duplicates: phones.length - cleaned.length,
            phones: cleaned
        };
    }

    async parseTXT(filePath) {
        const content = await fs.readFile(filePath, 'utf-8');
        return content.split(/[
,;|]/).map(l => l.trim()).filter(l => l);
    }

    async parseCSV(filePath) {
        return new Promise((resolve, reject) => {
            const phones = [];
            fs.createReadStream(filePath)
                .pipe(csv())
                .on('data', (row) => {
                    // Cari kolom yang mengandung phone/nomor/telp/wa
                    Object.values(row).forEach(val => {
                        if (val && val.toString().match(/[0-9]/)) {
                            phones.push(val.toString().trim());
                        }
                    });
                })
                .on('end', () => resolve(phones))
                .on('error', reject);
        });
    }

    async parseExcel(filePath) {
        const workbook = xlsx.readFile(filePath);
        const phones = [];

        workbook.SheetNames.forEach(sheetName => {
            const sheet = workbook.Sheets[sheetName];
            const data = xlsx.utils.sheet_to_json(sheet, { header: 1 });

            data.forEach(row => {
                row.forEach(cell => {
                    if (cell && cell.toString().match(/[0-9]/)) {
                        phones.push(cell.toString().trim());
                    }
                });
            });
        });

        return phones;
    }

    async parsePDF(filePath) {
        const buffer = await fs.readFile(filePath);
        const data = await pdfParse(buffer);
        const text = data.text;

        // Ekstrak nomor dari teks PDF
        const matches = text.match(/[\+]?[0-9\s\-\(\)]{10,}/g) || [];
        return matches.map(m => m.replace(/[^0-9]/g, '')).filter(m => m.length >= 10);
    }

    async parseZIP(filePath) {
        const zip = new AdmZip(filePath);
        const entries = zip.getEntries();
        let phones = [];

        const tempExtract = path.join(this.tempDir, `zip_${Date.now()}`);
        fs.ensureDirSync(tempExtract);
        zip.extractAllTo(tempExtract, true);

        for (const entry of entries) {
            if (entry.isDirectory) continue;
            const ext = path.extname(entry.entryName).toLowerCase();
            const extractPath = path.join(tempExtract, entry.entryName);

            if (['.txt', '.csv', '.xls', '.xlsx', '.vcf'].includes(ext)) {
                try {
                    const result = await this.processFile(extractPath, entry.entryName);
                    phones = phones.concat(result.phones);
                } catch (e) {}
            }
        }

        fs.removeSync(tempExtract);
        return phones;
    }

    async parseVCF(filePath) {
        const content = await fs.readFile(filePath, 'utf-8');
        const cards = vcf.parse(content);
        const phones = [];

        cards.forEach(card => {
            const tel = card.get('tel');
            if (tel) {
                phones.push(tel.valueOf());
            }
        });

        return phones;
    }

    saveContacts(userId, phones) {
        const db = require('../utils/database');
        const existing = db.getById('contacts', userId)?.list || [];
        const merged = [...new Set([...existing, ...phones])];

        db.setById('contacts', userId, {
            userId,
            list: merged,
            updatedAt: new Date().toISOString()
        });

        return merged.length;
    }

    clearContacts(userId) {
        const db = require('../utils/database');
        db.setById('contacts', userId, { userId, list: [], updatedAt: new Date().toISOString() });
    }
}

module.exports = new UploadHandler();
