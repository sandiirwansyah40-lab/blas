const {
    default: makeWASocket,
    DisconnectReason,
    useMultiFileAuthState,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore
} = require('@whiskeysockets/baileys');
const pino = require('pino')({ level: 'silent' });
const QRCode = require('qrcode');
const path = require('path');
const fs = require('fs-extra');
const db = require('../utils/database');
const logger = require('../utils/logger');
const { now } = require('../utils/helper');

const SESSION_DIR = path.join(__dirname, '..', 'session');
const sessions = new Map();
const qrCallbacks = new Map();
const pairingCallbacks = new Map();

class WhatsAppHandler {
    constructor() {
        this.sessions = sessions;
    }

    async createSession(userId, mode = 'qr', phoneNumber = null) {
        const sessionPath = path.join(SESSION_DIR, userId.toString());
        fs.ensureDirSync(sessionPath);

        // Hapus session lama jika ada
        if (sessions.has(userId)) {
            await this.logout(userId);
        }

        const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
        const { version } = await fetchLatestBaileysVersion();

        const sock = makeWASocket({
            version,
            logger: pino,
            printQRInTerminal: false,
            auth: {
                creds: state.creds,
                keys: makeCacheableSignalKeyStore(state.keys, pino)
            },
            browser: ['Ubuntu', 'Chrome', '22.04'],
            generateHighQualityLinkPreview: false,
            syncFullHistory: false,
            markOnlineOnConnect: false
        });

        sessions.set(userId, {
            sock,
            status: 'connecting',
            phone: null,
            connectedAt: null,
            qr: null,
            pairingCode: null
        });

        sock.ev.on('creds.update', saveCreds);

        sock.ev.on('connection.update', async (update) => {
            const { connection, lastDisconnect, qr } = update;

            if (qr) {
                const qrBuffer = await QRCode.toBuffer(qr);
                sessions.get(userId).qr = qrBuffer;
                sessions.get(userId).status = 'qr_ready';

                if (qrCallbacks.has(userId)) {
                    qrCallbacks.get(userId)({ type: 'qr', data: qrBuffer });
                }
            }

            if (connection === 'open') {
                const userJid = sock.user.id;
                const phone = userJid.split(':')[0].split('@')[0];

                sessions.get(userId).status = 'connected';
                sessions.get(userId).phone = phone;
                sessions.get(userId).connectedAt = now();
                sessions.get(userId).qr = null;
                sessions.get(userId).pairingCode = null;

                // Simpan ke database
                db.setById('sessions', userId, {
                    userId,
                    phone,
                    status: 'connected',
                    connectedAt: now(),
                    jid: userJid
                });

                if (qrCallbacks.has(userId)) {
                    qrCallbacks.get(userId)({ type: 'connected', phone });
                    qrCallbacks.delete(userId);
                }
                if (pairingCallbacks.has(userId)) {
                    pairingCallbacks.delete(userId);
                }

                logger.info({ msg: 'WhatsApp Connected', userId, phone });
            }

            if (connection === 'close') {
                const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;

                if (shouldReconnect) {
                    logger.info({ msg: 'WhatsApp reconnecting', userId });
                    setTimeout(() => this.createSession(userId, mode, phoneNumber), 3000);
                } else {
                    sessions.get(userId).status = 'disconnected';
                    db.setById('sessions', userId, {
                        ...db.getById('sessions', userId),
                        status: 'disconnected',
                        disconnectedAt: now()
                    });
                    logger.info({ msg: 'WhatsApp logged out', userId });
                }
            }
        });

        // Pairing Code
        if (mode === 'pairing' && phoneNumber) {
            setTimeout(async () => {
                try {
                    const code = await sock.requestPairingCode(phoneNumber);
                    sessions.get(userId).pairingCode = code;
                    sessions.get(userId).status = 'pairing';

                    if (pairingCallbacks.has(userId)) {
                        pairingCallbacks.get(userId)({ type: 'pairing', code });
                    }
                } catch (err) {
                    logger.error({ msg: 'Pairing code error', userId, error: err.message });
                    if (pairingCallbacks.has(userId)) {
                        pairingCallbacks.get(userId)({ type: 'error', message: err.message });
                    }
                }
            }, 3000);
        }

        return sessions.get(userId);
    }

    getSession(userId) {
        return sessions.get(userId) || null;
    }

    isConnected(userId) {
        const session = sessions.get(userId);
        return session && session.status === 'connected';
    }

    onQR(userId, callback) {
        qrCallbacks.set(userId, callback);
    }

    onPairing(userId, callback) {
        pairingCallbacks.set(userId, callback);
    }

    async sendMessage(userId, to, message, media = null) {
        const session = sessions.get(userId);
        if (!session || session.status !== 'connected') {
            throw new Error('WhatsApp tidak terhubung');
        }

        const jid = to.includes('@') ? to : `${to}@s.whatsapp.net`;

        if (media) {
            const { buffer, mimetype, filename, caption } = media;
            return await session.sock.sendMessage(jid, {
                document: buffer,
                mimetype,
                fileName: filename,
                caption: caption || message
            });
        }

        return await session.sock.sendMessage(jid, { text: message });
    }

    async logout(userId) {
        const session = sessions.get(userId);
        if (session && session.sock) {
            try {
                await session.sock.logout();
            } catch (e) {}
        }

        sessions.delete(userId);
        db.deleteById('sessions', userId);

        const sessionPath = path.join(SESSION_DIR, userId.toString());
        if (fs.existsSync(sessionPath)) {
            fs.removeSync(sessionPath);
        }

        logger.info({ msg: 'Session deleted', userId });
    }

    async deleteSession(userId) {
        await this.logout(userId);
    }

    getAllSessions() {
        const result = {};
        sessions.forEach((val, key) => {
            result[key] = {
                status: val.status,
                phone: val.phone,
                connectedAt: val.connectedAt
            };
        });
        return result;
    }

    async restoreSessions() {
        const savedSessions = db.get('sessions');
        for (const userId of Object.keys(savedSessions)) {
            const session = savedSessions[userId];
            if (session.status === 'connected') {
                try {
                    await this.createSession(userId, 'qr');
                    logger.info({ msg: 'Session restored', userId });
                } catch (err) {
                    logger.error({ msg: 'Restore session failed', userId, error: err.message });
                }
            }
        }
    }
}

module.exports = new WhatsAppHandler();
