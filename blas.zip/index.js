require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');
const express = require('express');
const path = require('path');
const fs = require('fs-extra');
const cron = require('node-cron');

const logger = require('./utils/logger');
const db = require('./utils/database');
const wa = require('./handler/whatsapp');
const admin = require('./handler/admin');

// Commands
const startCmd = require('./command/start');
const waCmd = require('./command/wa');
const uploadCmd = require('./command/upload');
const messageCmd = require('./command/message');
const blastCmd = require('./command/blast');
const balanceCmd = require('./command/balance');
const adminCmd = require('./command/admin');

const BOT_TOKEN = process.env.BOT_TOKEN;
const PORT = process.env.PORT || 3000;

if (!BOT_TOKEN) {
    logger.error('BOT_TOKEN tidak ditemukan di .env');
    process.exit(1);
}

// Inisialisasi Bot
const bot = new TelegramBot(BOT_TOKEN, {
    polling: {
        interval: 300,
        autoStart: true,
        params: { timeout: 10 }
    }
});

// Express Server (untuk health check & webhook opsional)
const app = express();
app.use(express.json());
app.get('/', (req, res) => res.json({ status: 'WhatsApp Blaster Bot Running', time: new Date().toISOString() }));
app.get('/health', (req, res) => res.json({ status: 'ok', uptime: process.uptime() }));
app.listen(PORT, () => logger.info(`Express server running on port ${PORT}`));

// Auto Backup setiap 24 jam
const backupInterval = parseInt(process.env.AUTO_BACKUP_INTERVAL) || 24;
cron.schedule(`0 */${backupInterval} * * *`, () => {
    try {
        const backupPath = db.backup();
        logger.info({ msg: 'Auto backup completed', path: backupPath });
    } catch (err) {
        logger.error({ msg: 'Auto backup failed', error: err.message });
    }
});

// Restore sessions on startup
(async () => {
    try {
        await wa.restoreSessions();
        logger.info('Sessions restore completed');
    } catch (err) {
        logger.error({ msg: 'Session restore error', error: err.message });
    }
})();

// Command Handler
bot.onText(/\/start/, (msg) => startCmd(bot, msg));

// Callback Query Handler
bot.on('callback_query', async (query) => {
    try {
        const data = query.data;

        if (data === 'start_menu') {
            await startCmd(bot, query.message);
            await bot.deleteMessage(query.message.chat.id, query.message.message_id).catch(() => {});
            return;
        }

        // Route ke handler yang sesuai
        if (data.startsWith('wa_')) await waCmd(bot, query);
        else if (data.startsWith('upload_')) await uploadCmd(bot, query);
        else if (data.startsWith('msg_') || data === 'message_menu') await messageCmd(bot, query);
        else if (data.startsWith('blast_')) await blastCmd(bot, query);
        else if (data.startsWith('balance_') || data.startsWith('wd_')) await balanceCmd(bot, query);
        else if (data.startsWith('admin_')) await adminCmd(bot, query);
        else if (data === 'history_menu') {
            await bot.editMessageText(
                `<b>📊 Riwayat</b>\n\nSilakan gunakan menu Saldo & WD untuk melihat riwayat transaksi.`,
                {
                    chat_id: query.message.chat.id,
                    message_id: query.message.message_id,
                    parse_mode: 'HTML',
                    reply_markup: { inline_keyboard: [[{ text: '◀️ Kembali', callback_data: 'start_menu' }]] }
                }
            );
        }

        await bot.answerCallbackQuery(query.id).catch(() => {});
    } catch (err) {
        logger.error({ msg: 'Callback error', error: err.message });
        await bot.answerCallbackQuery(query.id, { text: '❌ Terjadi kesalahan' }).catch(() => {});
    }
});

// Document Handler (Upload Kontak)
bot.on('document', async (msg) => {
    try {
        await uploadCmd.handleDocument(bot, msg);
    } catch (err) {
        logger.error({ msg: 'Document handler error', error: err.message });
    }
});

// Text Handler (State Management)
bot.on('message', async (msg) => {
    if (!msg.text || msg.text.startsWith('/')) return;

    const userId = msg.from.id;

    try {
        let handled = false;

        handled = await waCmd.handleText(bot, msg);
        if (handled) return;

        handled = await messageCmd.handleText(bot, msg);
        if (handled) return;

        handled = await blastCmd.handleText(bot, msg);
        if (handled) return;

        handled = await balanceCmd.handleText(bot, msg);
        if (handled) return;

        handled = await adminCmd.handleText(bot, msg);
        if (handled) return;
    } catch (err) {
        logger.error({ msg: 'Text handler error', userId, error: err.message });
    }
});

// Error Handler
bot.on('polling_error', (err) => {
    logger.error({ msg: 'Polling error', error: err.message });
});

bot.on('error', (err) => {
    logger.error({ msg: 'Bot error', error: err.message });
});

process.on('uncaughtException', (err) => {
    logger.error({ msg: 'Uncaught Exception', error: err.message, stack: err.stack });
});

process.on('unhandledRejection', (reason, promise) => {
    logger.error({ msg: 'Unhandled Rejection', reason: reason?.message || reason });
});

logger.info('WhatsApp Blaster Bot started successfully');
