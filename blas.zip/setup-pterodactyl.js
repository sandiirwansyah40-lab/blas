#!/usr/bin/env node
/**
 * Setup script khusus Pterodactyl Panel
 * Mengatasi error EALLOWGIT saat install @whiskeysockets/baileys
 */

const https = require('https');
const http = require('http');
const fs = require('fs');
const { execSync } = require('child_process');
const path = require('path');

// Multiple fallback URLs for libsignal-node
const LIBSIGNAL_URLS = [
    'https://api.github.com/repos/whiskeysockets/libsignal-node/tarball/main',
    'https://github.com/whiskeysockets/libsignal-node/archive/refs/heads/main.tar.gz',
    'https://codeload.github.com/whiskeysockets/libsignal-node/legacy.tar.gz/refs/heads/main'
];

const TEMP_DIR = path.join(__dirname, 'temp');
const NODE_MODULES = path.join(__dirname, 'node_modules');

function downloadFile(url, dest, redirectCount = 0) {
    return new Promise((resolve, reject) => {
        if (redirectCount > 5) {
            return reject(new Error('Too many redirects'));
        }

        const client = url.startsWith('https:') ? https : http;
        const options = {
            headers: {
                'User-Agent': 'Node.js/18.0.0',
                'Accept': 'application/vnd.github.v3+json'
            }
        };

        const req = client.get(url, options, (res) => {
            // Handle redirects
            if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
                console.log(`      ↪ Redirecting to ${res.headers.location.substring(0, 60)}...`);
                return downloadFile(res.headers.location, dest, redirectCount + 1)
                    .then(resolve).catch(reject);
            }

            if (res.statusCode !== 200) {
                return reject(new Error(`HTTP ${res.statusCode}`));
            }

            const file = fs.createWriteStream(dest);
            let downloaded = 0;
            const total = parseInt(res.headers['content-length']) || 0;

            res.on('data', (chunk) => {
                downloaded += chunk.length;
                if (total > 0 && downloaded % (1024 * 1024) < chunk.length) {
                    process.stdout.write(`\r      ⬇️  ${(downloaded / 1024 / 1024).toFixed(1)} MB / ${(total / 1024 / 1024).toFixed(1)} MB`);
                }
            });

            res.pipe(file);
            file.on('finish', () => {
                file.close();
                process.stdout.write('\n');
                resolve();
            });
        });

        req.on('error', (err) => {
            fs.unlink(dest, () => {});
            reject(err);
        });

        req.setTimeout(60000, () => {
            req.destroy();
            fs.unlink(dest, () => {});
            reject(new Error('Download timeout'));
        });
    });
}

async function tryDownload(urls, dest) {
    for (let i = 0; i < urls.length; i++) {
        console.log(`      Trying URL ${i + 1}/${urls.length}...`);
        try {
            await downloadFile(urls[i], dest);
            return true;
        } catch (err) {
            console.log(`      ❌ Failed: ${err.message}`);
            if (i < urls.length - 1) {
                console.log(`      Trying next URL...`);
            }
        }
    }
    return false;
}

async function setup() {
    console.log('========================================');
    console.log('  PTERODACTYL SETUP - WhatsApp Blaster');
    console.log('========================================\n');

    try {
        // Cleanup temp
        if (fs.existsSync(TEMP_DIR)) {
            fs.rmSync(TEMP_DIR, { recursive: true, force: true });
        }
        fs.mkdirSync(TEMP_DIR, { recursive: true });
        fs.mkdirSync(NODE_MODULES, { recursive: true });

        const tarPath = path.join(TEMP_DIR, 'libsignal.tar.gz');

        console.log('[1/4] ⬇️  Downloading libsignal-node from GitHub...');
        const success = await tryDownload(LIBSIGNAL_URLS, tarPath);

        if (!success) {
            throw new Error('All download URLs failed');
        }
        console.log('      ✅ Download complete\n');

        console.log('[2/4] 📂 Extracting libsignal-node...');
        execSync(`tar -xzf "${tarPath}" -C "${TEMP_DIR}"`, { stdio: 'pipe' });

        const files = fs.readdirSync(TEMP_DIR);
        const extracted = files.find(f => f.startsWith('whiskeysockets-libsignal-node') || f.startsWith('libsignal-node'));

        if (!extracted) {
            throw new Error('Could not find extracted libsignal-node folder');
        }

        const source = path.join(TEMP_DIR, extracted);
        const dest = path.join(NODE_MODULES, 'libsignal-node');

        if (fs.existsSync(dest)) {
            fs.rmSync(dest, { recursive: true, force: true });
        }
        fs.renameSync(source, dest);
        console.log('      ✅ Extracted to node_modules/libsignal-node\n');

        console.log('[3/4] 📦 Installing libsignal-node dependencies...');
        execSync('cd "node_modules/libsignal-node" && npm install --production --no-audit --no-fund --silent', {
            stdio: 'pipe',
            shell: true,
            timeout: 120000
        });
        console.log('      ✅ libsignal-node ready\n');

        console.log('[4/4] 🧹 Cleaning up...');
        fs.rmSync(TEMP_DIR, { recursive: true, force: true });
        console.log('      ✅ Cleanup complete\n');

        console.log('========================================');
        console.log('  ✅ SETUP BERHASIL!');
        console.log('========================================');
        console.log('\nLangkah selanjutnya:');
        console.log('  1. npm install --legacy-peer-deps');
        console.log('  2. npm start');
        console.log('\nAtau jika startup command Pterodactyl:');
        console.log('  npm install --legacy-peer-deps && npm start');
        console.log('');

    } catch (err) {
        console.error('\n========================================');
        console.error('  ❌ SETUP GAGAL');
        console.error('========================================');
        console.error('\nError:', err.message);
        console.error('\n💡 SOLUSI ALTERNATIF:');
        console.error('');
        console.error('   CARA 1 - Install di PC (Paling Mudah):');
        console.error('   1. Download & extract ZIP ini di PC/laptop');
        console.error('   2. Buka terminal di folder bot');
        console.error('   3. Jalankan: npm install');
        console.error('   4. Zip folder node_modules');
        console.error('   5. Upload node_modules.zip ke Pterodactyl');
        console.error('   6. Extract di Pterodactyl');
        console.error('   7. Jalankan: npm start');
        console.error('');
        console.error('   CARA 2 - Manual Download (Jika PC tidak tersedia):');
        console.error('   1. Buka browser, kunjungi:');
        console.error('      https://github.com/whiskeysockets/libsignal-node');
        console.error('   2. Klik Code → Download ZIP');
        console.error('   3. Upload ZIP ke Pterodactyl folder bot/');
        console.error('   4. Extract & rename jadi node_modules/libsignal-node');
        console.error('   5. cd node_modules/libsignal-node && npm install');
        console.error('   6. cd ../.. && npm install --legacy-peer-deps');
        console.error('   7. npm start');
        console.error('');
        process.exit(1);
    }
}

setup();
