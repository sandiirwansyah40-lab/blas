const fs = require('fs-extra');
const path = require('path');
const pino = require('pino')({ level: 'silent' });

const DB_PATH = path.join(__dirname, '..', 'database');

class Database {
    constructor() {
        this.cache = {};
        this.autoSaveInterval = 30000; // 30 detik
        this.init();
    }

    init() {
        const files = [
            'users.json', 'settings.json', 'sessions.json',
            'contacts.json', 'blast.json', 'withdraw.json',
            'balance.json', 'history.json', 'owner.json',
            'message.json', 'blast_history.json'
        ];

        files.forEach(file => {
            const filePath = path.join(DB_PATH, file);
            if (!fs.existsSync(filePath)) {
                fs.writeJsonSync(filePath, {});
            }
            this.cache[file.replace('.json', '')] = fs.readJsonSync(filePath);
        });

        // Auto save setiap 30 detik
        setInterval(() => this.saveAll(), this.autoSaveInterval);
    }

    get(collection) {
        return this.cache[collection] || {};
    }

    set(collection, data) {
        this.cache[collection] = data;
        this.save(collection);
    }

    getById(collection, id) {
        return this.cache[collection]?.[id] || null;
    }

    setById(collection, id, data) {
        if (!this.cache[collection]) this.cache[collection] = {};
        this.cache[collection][id] = data;
        this.save(collection);
    }

    deleteById(collection, id) {
        if (this.cache[collection]?.[id]) {
            delete this.cache[collection][id];
            this.save(collection);
        }
    }

    push(collection, id, key, value) {
        if (!this.cache[collection]) this.cache[collection] = {};
        if (!this.cache[collection][id]) this.cache[collection][id] = {};
        if (!Array.isArray(this.cache[collection][id][key])) {
            this.cache[collection][id][key] = [];
        }
        this.cache[collection][id][key].push(value);
        this.save(collection);
    }

    save(collection) {
        const filePath = path.join(DB_PATH, `${collection}.json`);
        try {
            fs.writeJsonSync(filePath, this.cache[collection], { spaces: 2 });
        } catch (err) {
            pino.error({ msg: 'Save DB error', collection, error: err.message });
        }
    }

    saveAll() {
        Object.keys(this.cache).forEach(collection => {
            this.save(collection);
        });
    }

    backup() {
        const backupDir = path.join(__dirname, '..', 'database', 'backup');
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const backupPath = path.join(backupDir, timestamp);

        fs.ensureDirSync(backupPath);

        Object.keys(this.cache).forEach(collection => {
            fs.writeJsonSync(
                path.join(backupPath, `${collection}.json`),
                this.cache[collection],
                { spaces: 2 }
            );
        });

        return backupPath;
    }

    restore(backupPath) {
        if (!fs.existsSync(backupPath)) return false;

        const files = fs.readdirSync(backupPath).filter(f => f.endsWith('.json'));
        files.forEach(file => {
            const collection = file.replace('.json', '');
            const data = fs.readJsonSync(path.join(backupPath, file));
            this.cache[collection] = data;
            this.save(collection);
        });

        return true;
    }
}

module.exports = new Database();
