const moment = require('moment-timezone');

const formatNumber = (num) => {
    return new Intl.NumberFormat('id-ID').format(num || 0);
};

const formatRupiah = (num) => {
    return 'Rp' + formatNumber(num);
};

const escapeHtml = (text) => {
    if (!text) return '';
    return text
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
};

const now = () => {
    return moment().tz('Asia/Jakarta').format('YYYY-MM-DD HH:mm:ss');
};

const today = () => {
    return moment().tz('Asia/Jakarta').format('YYYY-MM-DD');
};

const generateId = (prefix = '') => {
    return prefix + Date.now().toString(36) + Math.random().toString(36).substr(2, 5).toUpperCase();
};

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const validatePhone = (phone) => {
    if (!phone) return false;
    const cleaned = phone.toString().replace(/[^0-9]/g, '');
    return cleaned.length >= 10 && cleaned.length <= 15;
};

const cleanPhone = (phone) => {
    if (!phone) return '';
    let cleaned = phone.toString().replace(/[^0-9]/g, '');
    if (cleaned.startsWith('0')) cleaned = '62' + cleaned.slice(1);
    if (cleaned.startsWith('8')) cleaned = '62' + cleaned;
    if (!cleaned.startsWith('62')) cleaned = '62' + cleaned;
    return cleaned;
};

const progressBar = (current, total, size = 10) => {
    const percentage = total > 0 ? Math.round((current / total) * 100) : 0;
    const filled = Math.round((size * percentage) / 100);
    const empty = size - filled;
    return '█'.repeat(filled) + '░'.repeat(empty) + ` ${percentage}%`;
};

module.exports = {
    formatNumber,
    formatRupiah,
    escapeHtml,
    now,
    today,
    generateId,
    sleep,
    validatePhone,
    cleanPhone,
    progressBar
};
