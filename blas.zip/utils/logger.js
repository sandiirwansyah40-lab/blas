const pino = require('pino');
const path = require('path');
const fs = require('fs-extra');

const LOG_DIR = path.join(__dirname, '..', 'logs');
fs.ensureDirSync(LOG_DIR);

const logger = pino({
    level: 'info',
    transport: {
        targets: [
            {
                target: 'pino-pretty',
                options: {
                    colorize: true,
                    translateTime: 'SYS:yyyy-mm-dd HH:MM:ss',
                    ignore: 'pid,hostname'
                }
            },
            {
                target: 'pino/file',
                options: {
                    destination: path.join(LOG_DIR, `app-${new Date().toISOString().split('T')[0]}.log`),
                    mkdir: true
                }
            }
        ]
    }
});

module.exports = logger;
